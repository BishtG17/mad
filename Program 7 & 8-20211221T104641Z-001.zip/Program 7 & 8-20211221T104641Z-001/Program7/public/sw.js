const catchName = "version 1";
const cacheAssets = [
    "index.html",
    "error.html",
    "success.html"
]

self.addEventListener("install",event=>
console.log("sw is installed",event)
);

self.addEventListener("activate",event=>
console.log("sw is activatedd",event)
);

self.addEventListener("fetch",event=> {
console.log("sw is fetched");
event.respondWith(fetch(event.request).catch(()=> caches.match(event.request)));
});
