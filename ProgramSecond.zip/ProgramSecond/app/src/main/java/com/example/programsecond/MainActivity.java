package com.example.programsecond;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton img;
    Switch swt;
    ConstraintLayout custid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = findViewById(R.id.cust_butt);
        swt = findViewById(R.id.switch1);
        custid = findViewById(R.id.custid);

        CalendarView cv = new CalendarView(this);
        custid.addView(cv);



        swt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    custid.removeView(cv);
                    img.setEnabled(true);
                }else{
                    custid.addView(cv);
                    img.setEnabled(false);
                }
            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), "BUTTON PRESSED", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
